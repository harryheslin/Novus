﻿using System;
using System.Collections.Generic;
using Novus_HomeScreen.ViewModels;
using Novus_HomeScreen.Views;
using Xamarin.Forms;

namespace Novus_HomeScreen
{
    public partial class AppShell : Xamarin.Forms.Shell
    {
        public AppShell()
        {
            InitializeComponent();
            
        }

        private async void OnMenuItemClicked(object sender, EventArgs e)
        {
            await Shell.Current.GoToAsync("//LoginPage");
        }
    }
}
